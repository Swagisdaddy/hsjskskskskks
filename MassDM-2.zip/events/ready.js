const Discord = require("discord.js")
const { client, config } = require("../index.js")

client.on("ready", () => {

    console.log("|\n|    discord.gg/playboi | ! $wag#1629 \n|\n| Last Update: 16.6.2020\n|")

    client.user.setActivity(`discord.gg/playboi | ! $wag#1629 `, { type: "PLAYING" }).catch(console.error);

})